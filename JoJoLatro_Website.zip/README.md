# JoJoMod Website

Static website for JoJoMod v1.38.5, populated from the supplied mod source archive. The layout is adapted from the simple static Balatro mod website template by notmario (Unlicense / public domain dedication): https://github.com/notmario/balatrowebsitetemplate

## Preview locally

Because the gallery loads `data/jokers.json` with `fetch`, run a local static server instead of opening `index.html` as a `file://` URL.

```bash
python -m http.server 8000
```

Open http://localhost:8000.

## Deploy

Upload the contents of this folder to GitHub Pages, Netlify, or any static hosting provider. The mod ZIP is in `downloads/JojoMod_1_38_5.zip`.

## Notes

- Joker portraits are cropped from the local sprite atlases using the declared atlas cell size and Joker `pos`. Review unusual/custom atlas cards visually before publishing.
- Descriptions are sourced from `loc_txt.text`; values such as `#1#` are shown as `[value]` because they are dynamic.
- `assets/m6x11plus.ttf` is optional; place the template's font file there if you wish to use the exact font styling.
- The `Unlicense` source template is public domain; the JoJo and Balatro IP remains with its respective rights holders.


## Animated sprites and evolutions
The gallery uses the source mod sprite atlases for supported animated Jokers (Rohan, Mandom, Giorno, Kira, Tusk, and evolved D4C). Click a Joker with alternate forms and use the Evolution & Sprite Forms tiles to preview the relevant atlas frames. Browser previews approximate in-game animation; game timing and state are not simulated.
