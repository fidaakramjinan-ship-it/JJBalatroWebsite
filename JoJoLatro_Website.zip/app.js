const $ = (selector) => document.querySelector(selector);
const grid = $('#joker-grid');
const searchInput = $('#search');
const partFilter = $('#part-filter');
const rarityFilter = $('#rarity-filter');
const emptyState = $('#empty-state');
let allJokers = [];
const safe = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const partOrder = ['Part 3','Part 4','Part 5','Part 7','Part 8','Special'];
const rarityClass = (rarity) => String(rarity || '').toLowerCase();
const normalText = (lines) => (lines || []).join(' ').replace(/\s+/g,' ').trim();
function spriteMarkup(joker, extraClass = '') {
  if (joker.spriteSheet && joker.sheetCols && joker.sheetRows) {
    const anim = joker.animation;
    const useAnim = anim && anim.frames > 1;
    const row = useAnim ? anim.row : 0;
    const frameCount = useAnim ? anim.frames : 1;
    const fps = useAnim ? anim.fps : 1;
    const startX = useAnim ? (anim.startX || 0) : (joker.pos?.x || 0);
    const endX = startX + frameCount - 1;
    const xEnd = joker.sheetCols <= 1 ? 0 : endX / (joker.sheetCols - 1) * 100;
    const yPos = joker.sheetRows <= 1 ? 0 : row / (joker.sheetRows - 1) * 100;
    const xStart = joker.sheetCols <= 1 ? 0 : startX / (joker.sheetCols - 1) * 100;
    return `<div class="sprite-visual ${useAnim ? 'sprite-animated' : ''} ${safe(extraClass)}" style="--sheet:url('${safe(joker.spriteSheet)}');--cols:${joker.sheetCols};--rows:${joker.sheetRows};--sheet-width:${joker.sheetCols*100}%;--sheet-height:${joker.sheetRows*100}%;--x-start:${xStart}%;--x-end:${xEnd}%;--y-pos:${yPos}%;--duration:${(frameCount/fps).toFixed(3)}s;--steps:${frameCount}" aria-label="${safe(joker.name)} sprite"></div>`;
  }
  return `<img src="${safe(joker.image)}" alt="${safe(joker.name)} sprite" loading="lazy" onerror="this.onerror=null;this.src='assets/mod/modicon.png'">`;
}
function staticFormMarkup(joker, form) {
  if (!joker.spriteSheet) return '';
  const x = Number(form.x || 0), y = Number(form.y || 0);
  const xp = joker.sheetCols <= 1 ? 0 : x/(joker.sheetCols-1)*100;
  const yp = joker.sheetRows <= 1 ? 0 : y/(joker.sheetRows-1)*100;
  return `<div class="form-sprite" style="--sheet:url('${safe(joker.spriteSheet)}');--cols:${joker.sheetCols};--rows:${joker.sheetRows};--sheet-width:${joker.sheetCols*100}%;--sheet-height:${joker.sheetRows*100}%;--x-pos:${xp}%;--y-pos:${yp}%"></div>`;
}
function buildCard(joker) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'joker-card';
  btn.setAttribute('aria-label', `Details for ${joker.name}`);
  const lines = joker.ability || [];
  const ability = lines.slice(0,4).map(line => `<span class="ability-line">${safe(line)}</span>`).join('');
  btn.innerHTML = `
    <div class="card-topline"><span class="part-label">${safe(joker.part)}</span><span class="rarity ${rarityClass(joker.rarity)}">${safe(joker.rarity)}</span></div>
    <div class="card-art">${spriteMarkup(joker, 'card-sprite')}</div>
    <div class="card-bottom"><h3>${safe(joker.name)}</h3><span class="cost">${safe(joker.cost)}</span></div>
    <div class="card-ability">${ability || 'Ability details are defined in the mod source.'}</div>
    <div class="card-foot"><span>${safe(joker.partName || '')}</span><span>VIEW DETAILS ↗</span></div>`;
  btn.addEventListener('click', () => openJoker(joker));
  return btn;
}
function openJoker(joker) {
  const visual = $('#dialog-image');
  visual.className = 'dialog-sprite';
  visual.innerHTML = '';
  if (joker.spriteSheet && joker.sheetCols && joker.sheetRows) {
    const holder = document.createElement('div'); holder.innerHTML = spriteMarkup(joker, 'dialog-sprite-inner');
    visual.append(holder.firstElementChild);
  } else {
    const img = document.createElement('img'); img.src = joker.image; img.alt = joker.name; visual.append(img);
  }
  visual.setAttribute('aria-label', `${joker.name} sprite`);
  $('#dialog-name').textContent = joker.name;
  $('#dialog-part').textContent = `${joker.part} · ${joker.partName || ''}`;
  $('#dialog-rarity').textContent = joker.rarity;
  $('#dialog-rarity').className = `rarity ${rarityClass(joker.rarity)}`;
  $('#dialog-cost').textContent = joker.cost;
  $('#dialog-ability').innerHTML = (joker.ability || []).map(line => `<p>${safe(line)}</p>`).join('') || '<p>Ability details are defined in the mod source.</p>';
  const evoSection = $('#evolution-section');
  const evoList = $('#evolution-forms');
  evoList.replaceChildren();
  const forms = joker.evolutionForms || [];
  if (forms.length) {
    evoSection.hidden = false;
    for (const form of forms) {
      const tile = document.createElement('button');
      tile.type = 'button'; tile.className = 'evolution-tile';
      tile.innerHTML = `${staticFormMarkup(joker, form)}<strong>${safe(form.name)}</strong><span>${safe(form.note || '')}</span>`;
      tile.addEventListener('click', () => {
        const v = $('#dialog-image'); v.replaceChildren();
        if (joker.spriteSheet) {
          const xp = joker.sheetCols <= 1 ? 0 : Number(form.x || 0)/(joker.sheetCols-1)*100;
          const yp = joker.sheetRows <= 1 ? 0 : Number(form.y || 0)/(joker.sheetRows-1)*100;
          const el = document.createElement('div'); el.className = 'form-sprite selected-form';
          el.style.setProperty('--sheet', `url('${joker.spriteSheet}')`); el.style.setProperty('--cols', joker.sheetCols); el.style.setProperty('--rows', joker.sheetRows); el.style.setProperty('--sheet-width', `${joker.sheetCols*100}%`); el.style.setProperty('--sheet-height', `${joker.sheetRows*100}%`); el.style.setProperty('--x-pos', `${xp}%`); el.style.setProperty('--y-pos', `${yp}%`);
          const evoAnim = joker.evolutionAnimation;
          if (evoAnim && (form.name.includes('Requiem') || form.name.includes('Act 4') || form.name.includes('Love Train') || form.name.includes('Bites the Dust'))) {
            const startX = evoAnim.startX || 0, endX = startX + evoAnim.frames - 1;
            el.classList.add('sprite-animated'); el.style.setProperty('--x-start', `${joker.sheetCols <= 1 ? 0 : startX/(joker.sheetCols-1)*100}%`); el.style.setProperty('--x-end', `${joker.sheetCols <= 1 ? 0 : endX/(joker.sheetCols-1)*100}%`); el.style.setProperty('--y-pos', `${joker.sheetRows <= 1 ? 0 : evoAnim.row/(joker.sheetRows-1)*100}%`); el.style.setProperty('--duration', `${(evoAnim.frames/evoAnim.fps).toFixed(3)}s`); el.style.setProperty('--steps', evoAnim.frames);
          }
          v.append(el);
        }
        $('#dialog-name').textContent = `${joker.name} — ${form.name}`;
      });
      evoList.append(tile);
    }
  } else { evoSection.hidden = true; }
  const d = $('#joker-dialog');
  if (typeof d.showModal === 'function') d.showModal(); else d.setAttribute('open','');
}
function render() {
  const q = searchInput.value.trim().toLowerCase();
  const part = partFilter.value;
  const rarity = rarityFilter.value;
  const filtered = allJokers.filter(j => {
    const haystack = `${j.name} ${j.key} ${j.part} ${j.partName} ${normalText(j.ability)}`.toLowerCase();
    return (!q || haystack.includes(q)) && (part === 'all' || j.part === part) && (rarity === 'all' || j.rarity === rarity);
  });
  grid.replaceChildren(...filtered.map(buildCard));
  $('#visible-count').textContent = filtered.length;
  emptyState.hidden = filtered.length !== 0;
}
function initParts() {
  const parts = [...new Set(allJokers.map(j => j.part))].sort((a,b) => (partOrder.indexOf(a) < 0 ? 99 : partOrder.indexOf(a)) - (partOrder.indexOf(b) < 0 ? 99 : partOrder.indexOf(b)));
  for (const p of parts) {
    const option = document.createElement('option'); option.value = p; option.textContent = p;
    partFilter.append(option);
  }
}
async function init() {
  try {
    const res = await fetch('data/jokers.json');
    if (!res.ok) throw new Error('Could not load joker catalog');
    allJokers = await res.json();
    initParts();
    $('#joker-count').textContent = allJokers.length;
    render();
  } catch (err) {
    grid.innerHTML = `<p class="empty-state">Could not load the Joker data. Open this site through a local server or hosted URL so the JSON file can be fetched.</p>`;
    console.error(err);
  }
}
searchInput.addEventListener('input', render);
partFilter.addEventListener('change', render);
rarityFilter.addEventListener('change', render);
$('#reset-filters').addEventListener('click', () => { searchInput.value = ''; partFilter.value = 'all'; rarityFilter.value = 'all'; render(); });
$('#dialog-close').addEventListener('click', () => $('#joker-dialog').close());
$('#joker-dialog').addEventListener('click', (event) => { if (event.target === $('#joker-dialog')) $('#joker-dialog').close(); });
document.addEventListener('keydown', (event) => { if (event.key === '/' && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName)) { event.preventDefault(); searchInput.focus(); } if (event.key === 'Escape') $('#joker-dialog').close(); });

// Lightweight canvas motion: local and dependency-free, inspired by the template's animated background.
(() => {
  const canvas = $('#bg-canvas'), ctx = canvas.getContext('2d');
  let w = 0, h = 0, dpr = 1, t = 0;
  const resize = () => { dpr = Math.min(window.devicePixelRatio || 1, 1.7); w = window.innerWidth; h = window.innerHeight; canvas.width = w*dpr; canvas.height = h*dpr; ctx.setTransform(dpr,0,0,dpr,0,0); };
  const frame = () => {
    t += 0.004; ctx.clearRect(0,0,w,h);
    const cx=w*0.52, cy=h*0.25, max=Math.max(w,h)*0.9;
    for (let i=0;i<26;i++) {
      const a=i*Math.PI/13 + t*0.22, r=max*(0.14+(i%7)*0.09);
      const x=cx+Math.cos(a)*r, y=cy+Math.sin(a)*r*0.65;
      ctx.beginPath(); ctx.arc(x,y,Math.max(1,14-(i%10)),0,Math.PI*2);
      ctx.fillStyle = i%3===0 ? 'rgba(232,185,35,0.022)' : i%3===1 ? 'rgba(99,199,195,0.022)' : 'rgba(236,92,84,0.018)'; ctx.fill();
    }
    requestAnimationFrame(frame);
  };
  window.addEventListener('resize',resize,{passive:true}); resize(); frame();
})();
init();
